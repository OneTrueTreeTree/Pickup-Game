# Changelog
All notable changes to this project will be documented in this file.

## [1.0.0] - 2024-01-03
### Added
- Initial Package with Midgard Skybox.
- Contains 15 unique skyboxs in 4k.
